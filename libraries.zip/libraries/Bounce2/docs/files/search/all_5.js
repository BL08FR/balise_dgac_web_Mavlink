var searchData=
[
  ['interval',['interval',['../class_debouncer.html#a930bf3945e698d77b889f6309079857d',1,'Debouncer']]]
];
